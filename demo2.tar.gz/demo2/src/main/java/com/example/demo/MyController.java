package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyController {

    @Autowired
    PizzaCRUD crud;

    @GetMapping("/add") // http://127.0.0.1/add?name=234&size=20
    public @ResponseBody String addPizza(
            @RequestParam String name,
            @RequestParam Integer size) {
        Pizza pizza = new Pizza(name, size);
        crud.save(pizza);
        return "Successefull!";
    }

    @GetMapping("/all")
    public @ResponseBody Iterable<Pizza> getAll() {
        return crud.findAll();
    }
}
